import React, { Component } from 'react';

class Home extends Component {
  render() {
    return (
      <div>
        <div className="header">header</div>
         <div className="content">content</div>
         <div className="footer">footer</div>
      </div>
    )
  }
}

export default Home;